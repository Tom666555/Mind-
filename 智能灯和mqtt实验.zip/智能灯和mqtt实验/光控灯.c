/*!
 * MindPlus
 * mpython
 *
 */
#include <MPython.h>


// ������ʼ
void setup() {
	mPython.begin();
	display.setCursorLine(1);
	display.printLine("��ǰ��ǿ��");
}
void loop() {
	delay(3000);
	display.setCursorLine(2);
	display.printLine((light.read()));
	if (((light.read())<=1000)) {
		rgb.brightness(round(3));
		rgb.write(0, 0xFFFF00);
	}
	else {
		rgb.write(0, 0x000000);
	}
}
