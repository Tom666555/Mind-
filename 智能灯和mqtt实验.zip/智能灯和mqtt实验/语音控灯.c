/*!
 * MindPlus
 * mpython
 *
 */
#include <MPython.h>
#include <DFRobot_Iot.h>
#include <MPython_ASR.h>
// ��������
DFRobot_Iot myIot;
MPython_ASR mpythonAsr;
String      str_mpythonAsr_result;


// ������ʼ
void setup() {
	mPython.begin();
	display.setCursorLine(1);
	display.printLine("��������WiFi");
	myIot.wifiConnect("HUAWEI", "76543210");
	while (!myIot.wifiStatus()) {yield();}
	display.setCursorLine(2);
	display.printLine(myIot.getWiFiLocalIP());
	display.setCursorLine(3);
	display.printLine("����Aʶ��");
}
void loop() {
	if ((buttonA.isPressed())) {
		str_mpythonAsr_result=mpythonAsr.getAsrResult(2);
		display.setCursorLine(4);
		display.printLine((str_mpythonAsr_result));
	}
	else if (((String(str_mpythonAsr_result).indexOf(String("��")) != -1))) {
		rgb.brightness(round(3));
		rgb.write(0, 0xFFFF00);
	}
	else if (((String(str_mpythonAsr_result).indexOf(String("��")) != -1))) {
		rgb.write(0, 0x000000);
	}
}
