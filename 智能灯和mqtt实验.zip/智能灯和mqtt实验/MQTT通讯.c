/*!
 * MindPlus
 * mpython
 *
 */
#include <MPython.h>
#include <DFRobot_Iot.h>
// ��������
void onButtonAPressed();
void obloqMqttEventT0(String& message);
// ��̬����
const String topics[5] = {"tFYPzOFGR","W6PPkOFGg","","",""};
const MsgHandleCb msgHandles[5] = {obloqMqttEventT0,NULL,NULL,NULL,NULL};
// ��������
DFRobot_Iot myIot;


// ������ʼ
void setup() {
	mPython.begin();
	myIot.setMqttCallback(msgHandles);
	buttonA.setPressedCallback(onButtonAPressed);
	display.setCursorLine(1);
	display.printLine("��������WiFi,IPΪ");
	myIot.wifiConnect("HUAWEI", "76543210");
	while (!myIot.wifiStatus()) {yield();}
	display.setCursorLine(2);
	display.printLine(myIot.getWiFiLocalIP());
	myIot.init("iot.dfrobot.com.cn","JdJEkOFMg","","Jd1PzdFGRz",topics,1883);
	myIot.connect();
	while (!myIot.connected()) {yield();}
	display.setCursorLine(3);
	display.printLine("MQTT���ӳɹ�");
}
void loop() {

}

// �¼��ص�����
void onButtonAPressed() {
	myIot.publish(topic_1, "���");
	display.setCursorLine(4);
	display.printLine("���ͳɹ�");
}
void obloqMqttEventT0(String& message) {
	display.setCursorLine(4);
	display.printLine(message);
}
